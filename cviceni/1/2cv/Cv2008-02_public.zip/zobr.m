function I = zobr(I)
figure;
colormap(gray);
imagesc(I);
axis image;